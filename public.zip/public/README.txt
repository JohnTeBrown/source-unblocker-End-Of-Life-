README.txt

Node packages will remain empty for the managed chromebook editon of this unblocker.