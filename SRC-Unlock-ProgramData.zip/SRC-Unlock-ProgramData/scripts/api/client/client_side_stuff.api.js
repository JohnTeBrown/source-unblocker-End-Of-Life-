// client side code shall remain empty for now
// I'm leaving this empty as I cannot easily manipulate things that are client side
// makin the server connect with the client is hard, having the full version of node running would be great
// but sadly the linux beta is blocked
// Regards, Impulse admin.



// currentlty a WIP and not in use, though if you have the linux beta install coffeescript and the clientside test script will autocompile and run!
