// client side code shall remain empty for now
// I'm leaving this empty as I cannot easily manipulate things that are client side
// makin the server connect with the client is hard, having the full version of node running would be great
// but sadly the linux beta is blocked
// Regards, Impulse admin.



